function cfg = visualization_config()
%VISUALIZATION_CONFIG Canonical options for all maintained visualizers.

    cfg.show_map = true;
    cfg.show_regions = true;
    cfg.show_region_labels = true;
    cfg.show_tables = true;
    cfg.show_table_orientation = true;
    cfg.show_tasks = true;
    cfg.show_infeasible_tasks = true;
    cfg.show_candidates = false;
    cfg.candidate_stride = 20;
    cfg.show_selected_docks = true;
    cfg.show_sparse_graph = true;
    cfg.show_final_route = true;
    cfg.show_static_obstacles = true;
    cfg.show_start = true;
    cfg.show_legend = true;
    cfg.show_grid = true;
    cfg.save_png = true;
    cfg.save_fig = false;
    cfg.output_dir = fullfile('results', 'figures', 'complex_scene');
    cfg.figure_visible = 'off';
    cfg.dpi = 300;
    cfg.font_size = 11;

    % IEEE Robotics-style publication defaults shared by all stage renderers.
    cfg.style.name = 'ieee_robotics';
    cfg.style.font_name = 'Arial';
    cfg.style.font_size = 9;
    cfg.style.line_width = 1.4;
    cfg.style.axis_line_width = 0.8;
    cfg.style.background = [1 1 1];
    cfg.style.robot = [0.00 0.35 0.65];
    cfg.style.table = [0.45 0.45 0.45];
    cfg.style.task = [0.10 0.55 0.20];
    cfg.style.dock = [0.85 0.33 0.10];
    cfg.style.path = [0.00 0.20 0.80];
    cfg.style.region = [0.35 0.35 0.35];
    cfg.style.obstacle = [0.20 0.20 0.20];
    cfg.style.candidate = [0.55 0.55 0.55];
    cfg.style.grid = [0.92 0.92 0.92];
    cfg.output_names.scene = 'scene';
    cfg.output_names.candidate = 'candidate';
    cfg.output_names.candidate = 'candidate';
    cfg.output_names.docking = 'docking';
    cfg.output_names.planning = 'planning';
    cfg.output_names.replanning = 'replanning';

    % Compatibility values for the original stage visualizers.  Consumers
    % obtain the flattened form through legacy_visualization_config(); new
    % visualizers must use the canonical fields above.
    cfg.legacy.show_scene = true;
    cfg.legacy.show_candidates = true;
    cfg.legacy.show_docking = true;
    cfg.legacy.show_global_path = true;
    cfg.legacy.show_reachability = false;
    cfg.legacy.show_task_links = true;
    cfg.legacy.show_arm_assign = true;
    cfg.legacy.show_cost_heatmap = false;
    cfg.legacy.show_arm_task_links = false;
    cfg.legacy.show_task_dock_links = false;
    cfg.legacy.show_task_labels = true;
    cfg.legacy.show_dock_labels = true;
    cfg.legacy.show_arm_workspace = true;
    cfg.legacy.show_dock_coverage_text = true;
    cfg.legacy.show_dense_debug_info = false;
end
