function cfg = scene_config()
    %% ============================================================
    %  scene_config.m
    %
    %  Hardware-matched laboratory scene for ICRA experiment
    %
    %  Scene basis:
    %  - Experimental area: 9 x 7 floor tiles
    %  - Tile size: 0.60 m x 0.60 m
    %  - Map size: 5.40 m x 4.20 m
    %  - Six physical tables
    %  - Eight manually specified tabletop task points
    %
    %  Coordinate convention:
    %  - origin (0,0): lower-left corner of the experimental area
    %  - +x: left -> right in the top-view MATLAB map
    %  - +y: front -> back in the top-view MATLAB map
    %
    %  IMPORTANT:
    %  The table/task coordinates below are a PHOTO-DERIVED INITIALIZATION
    %  based on the 0.60 m floor-tile grid and the annotated experiment image.
    %  Before final paper submission, replace them with tape-measured values
    %  if available.
    %% ============================================================

    %% ===================== 1. Map parameters =====================
    cfg.map_width_m  = 5.40;
    cfg.map_height_m = 4.20;
    cfg.grid_resolution_m = 0.05;
    cfg.border_thickness_m = 0.05;
    cfg.tile_size_m = 0.60;

    %% ===================== 2. Table geometry =====================
    cfg.table.length = 1.200;
    cfg.table.width  = 0.600;
    cfg.table.height = 0.700;

    %% ===================== 3. Table layout =======================
    cfg.table_mode = 'custom';

    % Existing project convention: TABLE CENTER coordinates [x, y].
    cfg.table_positions = [
        1.20, 1.50;   % T1 left-front
        2.40, 2.70;   % T2 middle
        3.00, 3.80;   % T3 rear-middle
        3.60, 0.90;   % T4 right-front
        4.20, 2.10;   % T5 right-middle
        4.70, 3.30    % T6 right-rear
    ];

    cfg.num_tables = size(cfg.table_positions, 1);
    cfg.table_orientations = zeros(cfg.num_tables, 1);

    %% ===================== 4. Scene validation ===================
    cfg.table_min_spacing_m = 0.80;
    cfg.table_wall_margin_m = 0.05;
    cfg.table_start_margin_m = 0.80;

    %% ===================== 5. Robot start pose ===================
    cfg.start_pose = [0.60, 0.60, 0.0];

    %% ===================== 6. Task generation mode ===============
    cfg.task_mode = 'manual';
    cfg.task.difficulty = 'normal';
    cfg.task.hard_mixed_ratio = [0.4, 0.4, 0.2];
    cfg.tasks_per_table_range = [1, 1];
    cfg.random_seed = 2026;

    %% ===================== 7. Candidate local points =============
    % Retained for compatibility; manual tasks are used in this experiment.
    cfg.task_candidate_local = [
        -0.30,  0.20;
         0.00,  0.20;
         0.30,  0.20;
        -0.30, -0.20;
         0.00, -0.20;
         0.30, -0.20
    ];

    %% ===================== 8. Manual physical tasks ==============
    % Format: [table_id, x_world, y_world, z_world]
    %
    % Task numbering follows row order:
    % T4: Task 1, Task 2
    % T1: Task 3
    % T2: Task 4, Task 8
    % T5: Task 5
    % T6: Task 6
    % T3: Task 7

    z_task = cfg.table.height;

    cfg.manual_tasks = [
        4, 3.35, 0.80, z_task;   % Task 1
        4, 3.90, 0.80, z_task;   % Task 2
        1, 1.45, 1.40, z_task;   % Task 3
        2, 2.20, 2.60, z_task;   % Task 4
        5, 4.00, 2.00, z_task;   % Task 5
        6, 4.70, 3.20, z_task;   % Task 6
        3, 3.00, 3.70, z_task;   % Task 7
        2, 2.65, 2.60, z_task    % Task 8
    ];

    cfg.task_ids = (1:size(cfg.manual_tasks,1))';

    %% ===================== 9. Task height ========================
    cfg.task_offset_z = cfg.table.height;

    %% ===================== 10. Docking candidate parameters ======
    cfg.safety_margin_m = 0.05;
    cfg.docking_min_distance_m = 0.25;
    cfg.docking_max_distance_m = 0.40;
    cfg.docking_distance_step_m = 0.05;
    cfg.docking_lateral_step_m = 0.10;

    %% ===================== 11. Hardware-matched metadata =========
    cfg.scene_name = 'lab_hardware_matched';
    cfg.scene_source = 'annotated_physical_lab_photo';
    cfg.scene_coordinate_status = 'photo_initialized_not_final_measured';
    cfg.expected_task_count = 8;
    cfg.expected_table_count = 6;

end
